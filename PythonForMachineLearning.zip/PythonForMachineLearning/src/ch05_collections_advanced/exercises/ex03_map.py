values1 = [100, 200, 300, 400, 500]
values2 = [10, 20, 30, 40, 50]

result = [] # TODO

print(result)
