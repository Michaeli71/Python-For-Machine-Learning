nachricht = "Hallo lieber Workshop-Teilnehmer! Viel Spaß mit Python!"

print(len(nachricht))

print(nachricht[13])

print("Python" in "Hallo lieber Workshop-Teilnehmer! Viel Spaß mit Python!")