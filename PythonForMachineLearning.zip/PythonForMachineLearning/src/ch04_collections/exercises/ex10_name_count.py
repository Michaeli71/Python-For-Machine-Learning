names = ["Tim", "Tom", "Mike", "Jim", "Tim", "Mike", "James", "Mike"]

name_to_count_map = {}

# TODO

print(name_to_count_map)

