# Beispielprogramm für das Buch "Python Challenge"
#
# Copyright 2020 by Michael Inden


import turtle

my_turtle = turtle.Turtle()
screen = turtle.Screen()


def draw_spiral(myTurtle, lineLen):
    if lineLen > 0:
        myTurtle.forward(lineLen)
        myTurtle.right(90)
        draw_spiral(myTurtle, lineLen - 5)


draw_spiral(my_turtle, 200)
screen.exitonclick()
