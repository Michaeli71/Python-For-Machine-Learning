import itertools


def calc_permutations(input):
    # $\mbox{\bfseries recursive termination}$
    if is_blank(input) or len(input) == 1:
        return {input}

    combinations = set()
    # $\mbox{\bfseries extract i-th character as new first character}$
    for i, new_first in enumerate(input):
        # $\mbox{\bfseries recursive descent for rest without i-th character}$
        permutations = calc_permutations(input[0:i] + input[i + 1:])

        # $\mbox{\bfseries adding the extracted character to all partial solutions}$
        for perm in permutations:
            combinations.add(new_first + perm)

    return combinations


def is_blank(my_string):
    return not (my_string and my_string.strip())

def calc_permutations_mini_opt(input):
    return __calc_permutations_mini_opt_helper(input, "")


def __calc_permutations_mini_opt_helper(remaining, prefix):
    # $\mbox{\bfseries recursive termination}$
    if len(remaining) == 0:
        return {prefix}

    candidates = set()

    for i in range(len(remaining)):
        new_prefix = prefix + remaining[i]
        new_remaining = remaining[0: i] + remaining[i + 1:]

        # $\mbox{\bfseries recursive descent}$
        candidates.update(__calc_permutations_mini_opt_helper(new_remaining,
                                                              new_prefix))

    return candidates


def calc_permutations_built_in(input):
    result_tuples = list(itertools.permutations(input))

    return {"".join(tuple) for tuple in result_tuples}



import timeit
starttime = timeit.default_timer()
print("The start time is :",starttime)
calc_permutations("abcdefghij")
print("The time difference is :", timeit.default_timer() - starttime)

starttime = timeit.default_timer()
print("The start time is :",starttime)
calc_permutations_mini_opt("abcdefghij")
print("The time difference is :", timeit.default_timer() - starttime)

starttime = timeit.default_timer()
print("The start time is :",starttime)
calc_permutations_built_in("abcdefghij")
print("The time difference is :", timeit.default_timer() - starttime)