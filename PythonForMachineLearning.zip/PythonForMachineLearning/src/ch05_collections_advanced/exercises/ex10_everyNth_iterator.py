class EveryNth:
    # TODO

    def __iter__(self):
        pass

    def __next__(self):
        pass


thirdst_list = EveryNth([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], 3)
print(list(thirdst_list))

fifth_list = EveryNth([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], 5)
print(list(fifth_list))
