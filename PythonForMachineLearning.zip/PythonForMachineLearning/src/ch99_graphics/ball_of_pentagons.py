import turtle

for i in range(0,12):
    turtle.right(30)
    for i in range(5):
        turtle.forward(100)
        turtle.right(72)

turtle.hideturtle()
turtle.exitonclick()
