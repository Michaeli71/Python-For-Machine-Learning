# "Werte einer Tabelle"
values = [["Micha", 50, 8047, "Zürich"],
          ["Lili", 42, 8047, "Zürich"],
          ["Micha", 50, 52070, "Aachen"],
          ["Tim", 50, 24107, "Kiel"],
          ["Micha", 50, 24106, "Kiel"],
          ["Michael", 50, 24106, "Kiel"],
          ["Andreas", 50, 21012, "Hamburg"],
          ["Barbara", 48, 22395, "Hamburg"],
          ["Marianne", 83, 28816, "Stuhr"]]

# TODO