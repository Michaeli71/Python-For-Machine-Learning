def draw_ruler(major_tick_count, max_length):
    # TODO
    pass


draw_ruler(3, 4)