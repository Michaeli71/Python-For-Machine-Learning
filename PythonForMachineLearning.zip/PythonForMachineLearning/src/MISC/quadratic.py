# $\mbox{\bfseries brute force, three nested loops}$
def solve_quadratic_simple():
    for a in range(1, 100):
        for b in range(1, 100):
            for c in range(1, 100):
                # if a ** 2 + b ** 2 == c ** 2:
                # if pow(a,2) + pow(b,2) == pow(c,2):
                if a * a + b * b == c * c:
                    print("a =", a, "/ b =", b, "/ c =", c)