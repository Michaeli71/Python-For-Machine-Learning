def capitalize(input):
    input_chars = list(input)

    capitalize_next_char = True
    for i, current_char in enumerate(input_chars):
        if current_char.isspace():
            capitalize_next_char = True
        elif capitalize_next_char and current_char.isalpha():
            input_chars[i] = current_char.upper()
            capitalize_next_char = False

    return "".join(input_chars)


print(capitalize("seems to be okay"))
print(capitalize("what should happen with -a +b 1c"))


def capitalize_special(input):
    input_chars = list(input)

    capitalize_next_char = True
    for i, current_char in enumerate(input_chars):

        if current_char.isspace():
            capitalize_next_char = True
        elif capitalize_next_char:
            input_chars[i] = current_char.upper()
            capitalize_next_char = False

    return "".join(input_chars)


print(capitalize_special("seems to be okay"))
print(capitalize_special("what should happen with -a +b 1c"))