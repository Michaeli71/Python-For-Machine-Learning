def number_as_text(n):
    pass


print(number_as_text(721971))